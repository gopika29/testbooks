package com.cg.banking.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import com.cg.banking.services.BankingServices;

@Controller
public class BankingController {
	@Autowired
	BankingServices bankingServices;

	public BankingServices getBankingServices() {
		return bankingServices;
	}

	public void setBankingServices(BankingServices bankingServices) {
		this.bankingServices = bankingServices;
	}
	
}
