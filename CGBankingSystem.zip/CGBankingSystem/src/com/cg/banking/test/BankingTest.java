package com.cg.banking.test;

import static org.junit.Assert.*;

import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.banking.beans.Account;
import com.cg.banking.services.BankingServices;
import com.cg.banking.services.BankingServicesImpl;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.util.PayrollUtil;

public class BankingTest {
	private static BankingServices bankingServices;
	@BeforeClass
	public static void setUpTestEnv() {
		bankingServices=new BankingServicesImpl();
	}
	@Before
	public void setUpTestData() {
		Account account1=new 
	
	}
	@AfterClass
	public static void tearDownTestEnv() {
		bankingServices=null;
	}
}
