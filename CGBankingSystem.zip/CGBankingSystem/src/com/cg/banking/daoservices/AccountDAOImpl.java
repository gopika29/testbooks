package com.cg.banking.daoservices;

import java.util.ArrayList;
import java.util.List;

import com.cg.banking.beans.Account;
import com.cg.banking.util.BankingUtil;

public class AccountDAOImpl implements AccountDAO{
	
	@Override
	public Account save(Account account) {
		account.setAccountNo(BankingUtil.getACCOUNT_NUMBER());
		BankingUtil.accounts.put(account.getAccountNo(), account);
		return account;
	}

	@Override
	public boolean update(Account account) {
		BankingUtil.accounts.put(account.getAccountNo(), account);
		return true;
	}

	@Override
	public Account findOne(long accountNo) {
		return BankingUtil.accounts.get(accountNo);
		
	}

	@Override
	public List<Account> findAll() {
		return new ArrayList<>(BankingUtil.accounts.values());
		
	}

}
