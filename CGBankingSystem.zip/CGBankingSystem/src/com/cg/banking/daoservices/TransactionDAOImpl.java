package com.cg.banking.daoservices;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.cg.banking.beans.Transaction;
import com.cg.banking.util.BankingUtil;

public class TransactionDAOImpl implements TransactionDAO{

	@Override
	public Transaction save(Transaction transaction) {
		transaction.setTransactionId(BankingUtil.getTRANSACTION_ID());
		BankingUtil.transanctions.put(transaction.getTransactionId(), transaction);
		return transaction;
	}

	@Override
	public boolean update(Transaction transaction) {
		BankingUtil.transanctions.put(transaction.getTransactionId(), transaction);
		return true;
	}

	@Override
	public Transaction findOne(int transactionId) {
		return BankingUtil.transanctions.get(transactionId);
	}

	
	@Override
	public List<Transaction> findAll(long accountNo) {
		List<Transaction> transactionList=new ArrayList<>();
		for (Transaction transaction : new ArrayList<>(BankingUtil.transanctions.values())) {
			if(transaction.getAccountNo()==accountNo)
				transactionList.add(transaction);
		}
		return transactionList;
	}

}
