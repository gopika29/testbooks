package com.cg.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import com.cg.service.TraineeService;
@Controller
public class TraineeController {
	@Autowired
	TraineeService traineeService;

	public TraineeService getTraineeService() {
		return traineeService;
	}

	public void setTraineeService(TraineeService traineeService) {
		this.traineeService = traineeService;
	}
	
}
