package com.cg.dao;

import org.springframework.stereotype.Repository;

@Repository
public class TraineeDaoImpl implements TraineeDao{

}
