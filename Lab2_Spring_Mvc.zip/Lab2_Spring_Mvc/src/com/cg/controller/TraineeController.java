package com.cg.controller;
import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.bean.Login;
import com.cg.bean.Trainee;
import com.cg.service.TraineeService;
@Controller
public class TraineeController {
	@Autowired
	TraineeService traineeService;

	public TraineeService getTraineeService() {
		return traineeService;
	}

	public void setTraineeService(TraineeService traineeService) {
		this.traineeService = traineeService;
	}
	/*@RequestMapping(value="/loginPage",method=RequestMethod.GET)
	public String displayLoginPage(Model model) {
		model.addAttribute("login",new Login());
		return "LoginPage";
	}*/
	//------------------------validate user------------------------------
	@RequestMapping(value="/validateUser",method=RequestMethod.POST)
	public String validateUserDetails(@ModelAttribute(value="login") @Valid Login login,BindingResult result,
			Model model) {
		if(result.hasErrors())
			return "LoginPage";
		else {
			if(traineeService.adminValidation(login.getUserName(), login.getPassword())) {
				model.addAttribute("success","Login Success");
				return "Index";
			}
			else
				model.addAttribute("failure", "your username or password are wrong");
			return "LoginPage";
		}
	}
	//----------------------------------add User-------------------------------
	@ModelAttribute("domainList")
	public ArrayList<String> createTraineeDomainList() {
		ArrayList<String> domainList=new ArrayList<>();
		domainList.add("JAVA");
		domainList.add(".NET");
		domainList.add("CRM");
		domainList.add("BI");
		return domainList;
	}
	@RequestMapping(value="/addTrainee",method=RequestMethod.GET)//method is optional here
	public String displayRegisterPage(Model model,
			@ModelAttribute(value="domainList") ArrayList<String> domainList) {
		model.addAttribute("Add", new Trainee());
		model.addAttribute("domainList", domainList);
		return "AddTraineePage";
	}
	//-----------------------Insert User----------------------------------
	@RequestMapping(value="InsertUser",method=RequestMethod.POST)
	public String addUserDetails(@ModelAttribute(value="Add") @Valid Trainee trainee,
			BindingResult result,Model model) {
		traineeService.addTrainee(trainee);
		model.addAttribute("added","Data Added");
		return "AddTraineePage";
	}
	//------------------show delete Trainee Page---------------------------------
	@RequestMapping(value="/deleteTrainee",method=RequestMethod.GET)
	public String displayDeletePage(Model model) {
		model.addAttribute("message", "Enter trainee Id to delete data");
		model.addAttribute("delete",new Trainee());
		return "DeleteTraineePage";
	}
	//-----------------delete Operation-----------------------------------------
	@RequestMapping(value="/delete",method=RequestMethod.POST)
	public String deleteTrainee(@ModelAttribute(value="delete") Trainee trainee,Model model) {
		traineeService.deleteTrainee(trainee.getTraineeId());
		model.addAttribute("success", "delted successfully");
		return "DeleteTraineePage";	
	}
	//------------------show retrieve Trainee Page---------------------------------
	@RequestMapping(value="/RetrieveAtrainee",method=RequestMethod.GET)
	public String displayRetrieveTraineePage(Model model) {
		model.addAttribute("message", "Enter trainee Id you want to see");
		model.addAttribute("retrieve",new Trainee());
		return "RetrieveAtraineePage";
	}
	//-----------------retrieve Operation-----------------------------------------
	@RequestMapping(value="/retrieve",method=RequestMethod.POST)
	public String retrieveTrainee(@ModelAttribute(value="retrieve") Trainee trainee,Model model) {
		model.addAttribute("traineeDetails", traineeService.getTrainee(trainee.getTraineeId()));
		return "RetrieveAtraineePage";	
	}
	//------------------show retrieve All Trainees Page---------------------------------
		@RequestMapping(value="/RetrieveAll",method=RequestMethod.GET)
		public String retrieveAllTrainees(Model model) {
			model.addAttribute("traineeList", traineeService.getAllTrainees());
			return "RetrieveAllTrainees";
		}
//		@RequestMapping(value="/UpdateTrainee",method=RequestMethod.GET)
//		public String updateTraineePage(Model model) {
//			model.addAttribute("message", "Enter trainee Id you want to update");
//			model.addAttribute("trainee",new Trainee());
//			return "UpdatePage";
//		}
//		//---------------get Trainee Details to update--------------------------------------
//		@RequestMapping(value="/update",method=RequestMethod.POST)
//		public String updateTraineeDetails(@ModelAttribute(value="trainee") Trainee trainee,Model model) {
//			model.addAttribute("traineeDetails",traineeService.getTrainee(trainee.getTraineeId()));
//			return "UpdateDetailsPage";
//		}
//		//---------------------Update and save it to DataBase-----------------------------
//		@RequestMapping(value="/updateObject",method=RequestMethod.POST)
//		public String updateTraineeIntoDB(@ModelAttribute(value="trainee") Trainee trainee,Model model) {
//			model.addAttribute("trainee",traineeService.updateTrainee(trainee));
//			model.addAttribute("sucessMessage","updated Successfully");
//			return "UpdateDetailsPage";
//		}
		/**********************************************Modify Entry ID First Page Detail*****************************************************************************************/  
		@RequestMapping(value="/ShowModifyPage")
		public String displayModifyFirstPage(@ModelAttribute(value="modify")Trainee trainee,Model model) {
		      model.addAttribute("modify", trainee);
		    return "UpdatePage";
		}
		/**********************************************Display Modify Page to input the change to be done*****************************************************************************************/ 
		@RequestMapping(value="/DisplayModifyUser",method=RequestMethod.POST)
		public String displayModifyPage(@ModelAttribute(value="modify")Trainee trainee,Model model) {
		    Trainee traineeObjModel=traineeService.getTrainee(trainee.getTraineeId());
		    model.addAttribute("traineeObjModel", traineeObjModel);
		    return "UpdateDetailsPage";
		}
		/**********************************************Modify Detail*****************************************************************************************/  
		@RequestMapping(value="/Modify",method=RequestMethod.POST)
		public String modifyTraineeDetails(@ModelAttribute(value="modify")Trainee trainee,Model model) {
		    traineeService.updateTrainee(trainee);
		    model.addAttribute("message","updatedSuccessfully");
		    return"UpdateDetailsPage";
		}
}




