package com.cg.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.bean.Trainee;
import com.cg.dao.TraineeDao;

@Service
public class TraineeServiceImpl implements TraineeService{
	@Autowired
	TraineeDao traineeDao;

	public TraineeDao getTraineeDao() {
		return traineeDao;
	}

	public void setTraineeDao(TraineeDao traineeDao) {
		this.traineeDao = traineeDao;
	}

	@Override
	public boolean adminValidation(String userName, String password) {
		if(userName.equals("admin")&&password.equals("admin"))
			return true;
		return false;
	}

	@Override
	public Trainee addTrainee(Trainee trainee) {
		return traineeDao.addTrainee(trainee);
	}

	@Override
	public boolean deleteTrainee(int traineeId) {
		return traineeDao.deleteTrainee(traineeId);
	}

	@Override
	public Trainee getTrainee(int traineeId) {
		return traineeDao.getTrainee(traineeId);
	}

	@Override
	public ArrayList<Trainee> getAllTrainees() {
		return traineeDao.getAllTrainees();
	}

	@Override
	public boolean updateTrainee(Trainee trainee) {
		return traineeDao.updateTrainee(trainee);
	}
	
}
