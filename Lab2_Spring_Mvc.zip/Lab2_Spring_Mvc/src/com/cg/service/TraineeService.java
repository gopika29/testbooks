package com.cg.service;

import java.util.ArrayList;

import com.cg.bean.Trainee;

public interface TraineeService {
	public boolean adminValidation(String userName,String password);
	public Trainee addTrainee(Trainee trainee);
	public boolean deleteTrainee(int traineeId);
	public Trainee getTrainee(int traineeId);
	public ArrayList<Trainee> getAllTrainees();
	public boolean updateTrainee(Trainee trainee);
}
