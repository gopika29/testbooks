package com.cg.dao;

import java.util.ArrayList;
import java.util.List;

import com.cg.bean.Trainee;

public interface TraineeDao {
	public Trainee addTrainee(Trainee trainee);
	public boolean deleteTrainee(int traineeId);
	public Trainee getTrainee(int traineeId);
	public ArrayList<Trainee> getAllTrainees();
	public boolean updateTrainee(Trainee trainee);
}
