package com.cg.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.bean.Login;
import com.cg.bean.Trainee;

@Repository("traineeDao")
@Transactional
public class TraineeDaoImpl implements TraineeDao{
	@PersistenceContext
	EntityManager entityManager;
	
	public EntityManager getEntityManager() {
		return entityManager;
	}

	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	@Override
	public Trainee addTrainee(Trainee trainee) {
		entityManager.persist(trainee);
		return trainee;
	}

	@Override
	public boolean deleteTrainee(int traineeId) {
		entityManager.remove(entityManager.find(Trainee.class, traineeId));
		entityManager.flush();
		return true;
	}

	@Override
	public Trainee getTrainee(int traineeId) {
		return entityManager.find(Trainee.class, traineeId);
	}

	@SuppressWarnings("unchecked")
	@Override
	public ArrayList<Trainee> getAllTrainees() {
		return (ArrayList<Trainee>) entityManager.createQuery("from Trainee t").getResultList();
	}

	@Override
	public boolean updateTrainee(Trainee trainee) {
		/*entityManager.createQuery("update Trainee t set t.traineeName="+trainee.getTraineeName()+
				"where t.traineeId="+traineeId).executeUpdate();*/
		entityManager.merge(trainee);
		return true;
	}

}
