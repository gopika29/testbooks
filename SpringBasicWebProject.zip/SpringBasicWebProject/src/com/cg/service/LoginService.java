package com.cg.service;

import java.util.ArrayList;

import com.cg.bean.Login;
import com.cg.bean.Register;

public interface LoginService {
	public boolean isUserExist(String userName);
	public Login validateUser(Login login);
	public Register insertUserDetails(Register register);
	public ArrayList<Register>getAllDetails();
	public boolean deleteUser(String userName);
	public boolean updateUser(Register register);
}
