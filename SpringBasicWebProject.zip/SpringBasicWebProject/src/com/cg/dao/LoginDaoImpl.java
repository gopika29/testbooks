package com.cg.dao;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.bean.Login;
import com.cg.bean.Register;
@Repository("loginDao")
@Transactional
public class LoginDaoImpl implements LoginDao{
	@PersistenceContext
	EntityManager entityManager; 
	public EntityManager getEntityManager() {
		return entityManager;
	}
	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	@Override
	public boolean isUserExist(String userName) {
		if ((entityManager.find(Login.class, userName))!=null) 
			return true;	
		return false;
	}

	@Override
	public Login validateUser(Login login) {
		return entityManager.find(Login.class, login.getUserName());
	}
	@Override
	public Register insertUserDetails(Register register) {
		entityManager.persist(new Login(register.getUserName(), register.getPassword()));
		StringBuffer str=new StringBuffer();
		for (String tempStr:register.getSkillSet() )
			str.append(tempStr+",");
		register.setSkillSetString(str.toString());
		entityManager.persist(register);
		entityManager.flush();
		return entityManager.find(Register.class, register.getUserName());
	}
	@Override
	public ArrayList<Register> findAll() {
		return (ArrayList<Register>) entityManager.createQuery("From Register R").getResultList();
	}
	@Override
	public boolean deleteUser(String userName) {
		entityManager.remove(entityManager.find(Register.class, userName));
		entityManager.remove(entityManager.find(Login.class, userName));
		entityManager.flush();
		return true;
	}
	@Override
	public boolean updateUser(Register register) {
		entityManager.merge(register);
		entityManager.flush();
		return true;
	}

}
