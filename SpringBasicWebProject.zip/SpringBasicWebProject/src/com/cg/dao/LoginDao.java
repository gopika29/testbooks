package com.cg.dao;

import java.util.ArrayList;

import com.cg.bean.Login;
import com.cg.bean.Register;

public interface LoginDao {
	public boolean isUserExist(String userName);
	public Login validateUser(Login login);
	public Register insertUserDetails(Register register);
	public ArrayList<Register> findAll();
	public boolean deleteUser(String userName);
	public boolean updateUser(Register register);
}
