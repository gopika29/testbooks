package com.cg.bean;

import java.util.Arrays;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.constraints.Pattern;
import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotEmpty;
@Entity
@Table(name="CG_UserDetails")
public class Register {
	@Pattern(regexp="^([0-9]+[a-zA-Z]+|[a-zA-Z]+[0-9]+)[0-9a-zA-Z]*$",
			message="must contain alphanumeric characters")
	@Id
	@Column(name="user_name",length=25)
	private String userName;
	@Transient
	private String password;
	@Transient
	private String confirmPassword;
	@Column(name="first_name",length=20)
	private String firstName;
	@Column(name="last_name",length=20)
	private String lastName;
	@Email(message="provide proper email address")
	@Column(name="user_email",length=30)
	private String emailId;
	@Transient
	private String[] skillSet;
	@NotEmpty(message="select your gender")
	@Column(name="user_gender",length=1)
	private String gender;
	@NotEmpty(message="select your city")
	@Column(name="user_city")
	private String city;
	@Column(name="user_skills",length=100)
	private String skillSetString;
	
	public String getSkillSetString() {
		return skillSetString;
	}
	public void setSkillSetString(String skillSetString) {
		this.skillSetString = skillSetString;
	}
	public Register() {}
	public Register(String userName, String password, String confirmPassword, String firstName, String lastName,
			String emailId, String[] skillSet, String gender, String city) {
		super();
		this.userName = userName;
		this.password = password;
		this.confirmPassword = confirmPassword;
		this.firstName = firstName;
		this.lastName = lastName;
		this.emailId = emailId;
		this.skillSet = skillSet;
		this.gender = gender;
		this.city = city;
	}
	
	public Register(String userName, String firstName, String lastName, String emailId, String[] skillSet,
			String city) {
		super();
		this.userName = userName;
		this.firstName = firstName;
		this.lastName = lastName;
		this.emailId = emailId;
		this.skillSet = skillSet;
		this.city = city;
	}
	@NotEmpty(message="this field can't be empty")
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	@NotEmpty(message="this field can't be empty")
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	@NotEmpty(message="this field can't be empty")
	public String getConfirmPassword() {
		return confirmPassword;
	}
	public void setConfirmPassword(String confirmPassword) {
		this.confirmPassword = confirmPassword;
	}
	@NotEmpty(message="this field can't be empty")
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	@NotEmpty(message="this field can't be empty")
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	@NotEmpty(message="field can't be empty")
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	@NotEmpty(message="this field can't be empty")
	public String[] getSkillSet() {
		return skillSet;
	}
	public void setSkillSet(String[] skillSet) {
		this.skillSet = skillSet;
	}
	
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	@NotEmpty(message="this field can't be empty")
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	@Override
	public String toString() {
		return "Register [userName=" + userName + ", password=" + password + ", confirmPassword=" + confirmPassword
				+ ", firstName=" + firstName + ", lastName=" + lastName + ", emailId=" + emailId + ", skillSet="
				+ Arrays.toString(skillSet) + ", gender=" + gender + ", city=" + city + "]";
	}
	
}
